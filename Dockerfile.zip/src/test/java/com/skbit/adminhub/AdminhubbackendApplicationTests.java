package com.skbit.adminhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminhubbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
