package com.skbit.techrel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class techrelbackend {

	public static void main(String[] args) {
		SpringApplication.run(techrelbackend.class, args);
	}                                                          

	
}
	